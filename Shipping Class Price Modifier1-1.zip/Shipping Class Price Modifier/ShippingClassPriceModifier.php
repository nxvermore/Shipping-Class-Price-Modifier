<?php
/**
 * Plugin Name: Shipping Class Price Modifier
 * Description: Modifies the price of shipping classes based on the number of items in the cart
 * Version: 1.1
 * Author: Nxvermore
 */

// Add a custom shipping class
add_filter( 'woocommerce_shipping_classes', 'add_custom_shipping_class' );
function add_custom_shipping_class( $classes ) {
    $classes['free-shipping'] = array(
        'slug' => 'free-shipping',
        'name' => __('Free Shipping', 'woocommerce')
    );
    return $classes;
}

// Modify the price of the shipping class based on the number of items in the cart
add_action( 'woocommerce_cart_calculate_fees', 'modify_shipping_class_price' );
function modify_shipping_class_price() {
    $cart_count = WC()->cart->get_cart_contents_count();

    if ( $cart_count >= 3 ) {
        // Free shipping in Spain for 3 or more items
        $shipping_class = 'free-shipping';
        $destination = 'ES';
        $has_shipping_class = false;

        // Check if the free shipping class already exists
        foreach ( WC()->shipping()->get_shipping_classes() as $shipping_class ) {
            if ( $shipping_class->term_id === $shipping_class_id ) {
                $has_shipping_class = true;
                break;
            }
        }

        // If the free shipping class doesn't exist, create it
        if ( ! $has_shipping_class ) {
            WC()->shipping()->add_shipping_class( $shipping_class, 'Free Shipping', true );
        }

        // Set the price to 0 for the free shipping class
        WC()->session->set( 'shipping_for_package_0' . '_' . $destination . '_' . $shipping_class, 0 );
    } elseif ( $cart_count >= 5 ) {
        // Free shipping in Europe for 5 or more items
        $shipping_class = 'free-shipping';
        $destination = array( 'DE', 'FR', 'IT', 'ES', 'PT', 'NL', 'BE', 'AT', 'LU', 'IE', 'DK', 'SE', 'FI', 'PL', 'CZ', 'SK', 'HU', 'SI', 'HR', 'BG', 'RO' );
        $has_shipping_class = false;

        // Check if the free shipping class already exists
        foreach ( WC()->shipping()->get_shipping_classes() as $shipping_class ) {
            if ( $shipping_class->get_slug() === 'free-shipping' ) {
                $has_shipping_class = true;
                break;
            }
        }

        // If the free shipping class doesn't exist, create it
        if ( ! $has_shipping_class ) {
            WC()->shipping()->add_shipping_class( $shipping_class, 'Free Shipping', true );
        }

        // Set the price to 0 for the free shipping class
        foreach ( $destination as $dest ) {
            WC()->session->set( 'shipping_for_package_0' . '_' . $dest . '_' . $shipping_class, 0 );
        }
    } elseif ( $cart_count >= 10 ) {
        // Free shipping in USA and Asia for 10 or more items
        $shipping_class = 'free-shipping';
        $destination = array( 'US', 'CN', 'JP', 'KR', 'SG', 'MY', 'ID', 'TH', 'VN', 'PH', 'IN' );
        $has_shipping_class = false;

        // Check if the free shipping class already exists
        foreach ( WC()->shipping()->get_shipping_classes() as $shipping_class ) {
            if ( $shipping_class->get_slug() === 'free-shipping' ) {
            $has_shipping_class = true;
            break;
            }
        }
    // If the free shipping class doesn't exist, create it
    if ( ! $has_shipping_class ) {
        WC()->shipping()->add_shipping_class( $shipping_class, 'Free Shipping', true );
    }

    // Set the price to 0 for the free shipping class
    foreach ( $destination as $dest ) {
        WC()->session->set( 'shipping_for_package_0' . '_' . $dest . '_' . $shipping_class, 0 );
    }
}
}